<#
	My Function
#>
function Get-Function {

}